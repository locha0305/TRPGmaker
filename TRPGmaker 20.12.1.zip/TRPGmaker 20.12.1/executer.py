import ntcompiler as nt
import datatype as dt
from termcolor import colored
import os
import sys
import math
import random
import time
from datetime import datetime




class Player():
    def __init__(self):
        self.maxhp = nt.ntobject('player/player.txt').attr("player")["maxhp"]
        self.hp = self.maxhp
        self.maxmp = nt.ntobject('player/player.txt').attr("player")["maxmp"]
        self.mp = self.maxmp
        self.xp = nt.ntobject('player/player.txt').attr("player")["xp"]
        self.gold = nt.ntobject('player/player.txt').attr("player")["gold"]
        self.displayname = nt.ntobject('player/player.txt').attr("player")["displayname"]
        self.weapon_inventory = {}
        self.item_inventory = {}
        self.skills = {}
        self.level = int(math.log2(self.xp + 2))
        for slot in range(0, 10):
            self.weapon_inventory[slot] = {"name":None, "type":"", "dmg":1, "enchantment":"", "durability":9999999999999, "level":1}
        for slot in range(0, 10):
            self.item_inventory[slot] = {"name":None, "stack":0, "code":""}
        for slot in range(0, 10):
            self.skills[slot] = {"name":None, "type":"", "maxcooltime":0, "cooltime":0, "code":""}
class Entity():
    def __init__(self):
        pass
def clear():
    os.system('cls')

def load(route):
    #for code loading
    with open(route, 'r', encoding='UTF-8') as file:
        codes = file.readlines()
        code = ""
        for lines in codes:
            code += lines
    if code == "":
        pass
    else:
        exec(code)

def give_weapon(weapon_name):
    global player, weapon_list
    weapon_type = weapon_list[weapon_name]["type"]
    weapon_dmg = weapon_list[weapon_name]["dmg"]
    weapon_dur = weapon_list[weapon_name]["durability"]
    
    for slot in player.weapon_inventory:
        if player.weapon_inventory[slot]["name"] == None:
            player.weapon_inventory[slot]["name"] = weapon_name
            player.weapon_inventory[slot]["type"] = weapon_type
            player.weapon_inventory[slot]["dmg"] = weapon_dmg
            player.weapon_inventory[slot]["durability"] = weapon_dur
            player.weapon_inventory[slot]["level"] = 1
            break
        else:
            pass
def give_item(item_name, item_num):
    global player, item_list
    item_code = item_list[item_name]["run"]

    for slot in player.item_inventory:
        if player.item_inventory[slot]["name"] == item_name:
            player.item_inventory[slot]["stack"] += item_num
            break
        if player.item_inventory[slot]["name"] == None:
            player.item_inventory[slot]["name"] = item_name
            player.item_inventory[slot]["stack"] = item_num
            player.item_inventory[slot]["code"] = item_code
            break
        else:
            pass
def give_gold(gold):
    global player
    player.gold += gold

def give_xp(xp):
    global player
    player.xp += xp

def replace_weapon_none(slot):
    global player
    player.weapon_inventory[slot] = {"name":None, "type":"", "dmg":1, "enchantment":[], "durability":9999999999999, "level":1}

def assign(skill_name):
    global player, skill_list
    skill_code = skill_list[skill_name]["run"]
    skill_maxcooltime = skill_list[skill_name]["maxcooltime"]
    skill_cost = skill_list[skill_name]["cost"]
    skill_cooltime = skill_maxcooltime
    for slot in player.skills:
        if player.skills[slot]["name"] == skill_name:
            break
        elif player.skills[slot]["name"] == None:
            player.skills[slot]["name"] = skill_name
            player.skills[slot]["run"] = skill_code
            player.skills[slot]["cost"] = skill_cost
            player.skills[slot]["maxcooltime"] = skill_maxcooltime
            player.skills[slot]["cooltime"] = skill_cooltime
            break
        else:
            pass


def kill():
    global player
    clear()
    print(colored("{}가 사망하였습니다".format(player.displayname), 'red'))
    input()
    main()

def choice(choices, error_msg):
    global player
    for choice_ in choices:
        print("[{}]{}".format(choice_, choices[choice_]["show"]))
    ans = input(": ")
    if ans in choices:
        exec(choices[ans]["run"])
    else:
        print(error_msg)
        input()

def inv_choice(choices, error_msg):
    global player
    for choice_ in choices:
        print("[{}]{}".format(choice_, choices[choice_]["show"]))
    print("[i]인벤토리")
    ans = input(": ")
    if ans in choices:
        exec(choices[ans]["run"])
    elif ans == "i":
        show_inventory()
    else:
        print(error_msg)
        input()

def msg(sender, contents):
    print("[{}]{}".format(sender, contents))

def sysmsg(contents):
    print("[sys]{}".format(contents))

def recalc():
    global player
    player.level = int(math.log2(player.xp + 2))
    for slot in player.weapon_inventory:
        if player.weapon_inventory[slot]["durability"] <= 0:
            replace_weapon_none(slot)
def calc_level():
    global player
    player.level = int(math.log2(player.xp + 2))
def show_interface():
    global player
    player.level = int(math.log2(player.xp + 2))
    for slot in player.weapon_inventory:
        if player.weapon_inventory[slot]["durability"] <= 0:
            replace_weapon_none(slot)
    for slot in player.item_inventory:
        if player.item_inventory[slot]["stack"] <= 0:
            player.item_inventory[slot] = {"name":None, "stack":0, "code":""}
    print("[{}]{}".format(player.level, player.displayname))
    print(colored("hp : {}/{}".format(player.hp, player.maxhp), 'red'))
    print(colored("mp : {}/{}".format(player.mp, player.maxmp), 'blue'))
    print(colored("gold : {}".format(player.gold), 'yellow'))

def show_inventory():
    global player
    print("- 인벤토리")
    print("[w]무기")
    print("[s]스킬")
    print("[i]아이템")
    print("[q]나가기")
    ans = input(": ")
    if ans == "w":
        print("- 무기")
        for slot in player.weapon_inventory:
            print("[{}]{}".format(slot, player.weapon_inventory[slot]["name"]))
        print("[q]나가기 [0~9]슬롯번호")
        ans = input(": ")
        if ans.isdigit():
            try:
                slot = int(ans)
                weapon = player.weapon_inventory[slot]
                if weapon["name"] == None:
                    print("[{}]{}".format(weapon["level"], "hand"))
                    print("the most basic weapon")
                else:
                    print("[{}]{}".format(weapon["level"], weapon["name"]))
                    print("{}".format(weapon_list[weapon["name"]]["description"]))
                print("내구도 : {}".format(weapon["durability"]))
                print("[h]들기 [t]버리기 [q]나가기")
                ans = input(": ")
                if ans == "h":
                    weapon_mainhand = player.weapon_inventory[0]
                    weapon_slot = player.weapon_inventory[slot]
                    player.weapon_inventory[0] = weapon_slot
                    player.weapon_inventory[slot] = weapon_mainhand
                    show_inventory()
                elif ans == "t":
                    replace_weapon_none(slot)
                    show_inventory()
                elif ans == "q":
                    show_inventory()
                else:
                    print("제대로 된 값을 입력하세요")
                    input()
                    show_inventory()
            except:
                print("제대로 된 값을 입력하세요")
                input()
                show_inventory()
        elif ans == "q":
            show_inventory() 
                
    elif ans == "i":
        print("- 아이템")
        for slot in player.item_inventory:
            print("[{}]{}<{}개>".format(slot, player.item_inventory[slot]["name"], player.item_inventory[slot]["stack"]))
        print("[q]나가기")
        ans = input(": ")
        if ans == "q":
            show_inventory()
        else:
            print("제대로 된 값을 입력하세요")
            input()
    elif ans == "s":
        print("- 스킬")
        for slot in player.skills:
            print("[{}]{}".format(slot, player.skills[slot]["name"]))
        print("[q]나가기")
        ans = input(": ")
        if ans == "q":
            show_inventory()
        else:
            print("제대로 된 값을 입력하세요")
            input()
    elif ans == "q":
        pass
    else:
        print("제대로 된 값을 입력하세요")
        input()

def world(world):
    show_interface()
    load("worlds/{}.txt".format(world))

def save(savepoint):
    global player
    with open('saves/player.txt', 'w') as player_save:
        player_save.writelines(['player{\n', 'maxhp:{}\n'.format(player.maxhp), 'hp:{}\n'.format(player.hp), 'maxmp:{}\n'.format(player.maxmp), 'mp:{}\n'.format(player.mp), 'gold:{}\n'.format(player.gold), 'xp:{}\n'.format(player.xp), 'displayname:"{}"\n'.format(player.displayname), '{'])
    with open('saves/savepoint.txt', 'w') as position_save:
        position_save.writelines(['savepoint{\n', 'savepoint:"{}"\n'.format(savepoint), '}'])
    with open('saves/weapons.txt', 'w') as weapon_save:
        weapons_save = []
        for slot in player.weapon_inventory:
            weapons_save.append(str(slot) + '{\n')
            weapons_save.append('name:"{}"\n'.format(player.weapon_inventory[slot]["name"]))
            weapons_save.append('type:"{}"\n'.format(player.weapon_inventory[slot]["type"]))
            weapons_save.append('durability:{}\n'.format(player.weapon_inventory[slot]["durability"]))
            weapons_save.append('level:{}\n'.format(player.weapon_inventory[slot]["level"]))
            weapons_save.append('dmg:{}\n'.format(player.weapon_inventory[slot]["dmg"]))
            weapons_save.append("{\n")
        weapon_save.writelines(weapons_save)
    with open('saves/skills.txt', 'w') as skill_save:
        skills_save = []
        for slot in player.skills:
            skills_save.append(str(slot) + '{\n')
            skills_save.append('name:"{}"\n'.format(player.skills[slot]["name"]))
            skills_save.append('type:"{}"\n'.format(player.skills[slot]["type"]))
            skills_save.append('cooltime:{}\n'.format(player.skills[slot]["cooltime"]))
            skills_save.append('maxcooltime:{}\n'.format(player.skills[slot]["maxcooltime"]))
            skills_save.append('code:"{}"\n'.format(player.skills[slot]["code"]))
            skills_save.append("{\n")
        skill_save.writelines(skills_save)
    with open('saves/items.txt', 'w') as item_save:
        items_save = []
        for slot in player.item_inventory:
            items_save.append(str(slot) + '{\n')
            items_save.append('name:"{}"\n'.format(player.item_inventory[slot]["name"]))
            items_save.append('stack:{}\n'.format(player.item_inventory[slot]["stack"]))
            items_save.append('code:"{}"\n'.format(player.item_inventory[slot]["code"]))
            items_save.append("{\n")
        item_save.writelines(items_save)
def battle(entity, level):
    global entity_list, weapon_list, player, opp
    opp = Entity()
    entity_ = entity_list[entity]
    opp.name = entity
    opp.mainhand = weapon_list[entity_["mainhand"]]
    opp.dmg = opp.mainhand["dmg"] + level * 2
    
    opp.hp = entity_["hp"] + level * 2
    opp.lv = level
    turn = 0
    while opp.hp > 0 and player.hp > 0:
        clear()
        print("[{}]{}".format(opp.lv, opp.name))
        print(colored("{} hp : {}".format(opp.name, opp.hp), "red"))
        print(colored("{} hp : {}".format(player.displayname, player.hp), "red"))
        print(colored("{} mp : {}".format(player.displayname, player.mp), "blue"))
        print("[1]공격")
        print("[2]스킬 사용")
        print("[3]아이템 사용")
        print("[4]턴 넘기기")
        ans = input(": ")
        if ans == "1":
            turn += 1
            player_dmg = player.weapon_inventory[0]["dmg"] + player.weapon_inventory[0]["level"] * 2
            print("{}는 공격을 시도했다".format(player.displayname))
            critical = random.randrange(1, 6) #1, 2, 3, 4, 5 ==> 1, 2, 0, 1, 2
            if critical % 3 == 0:
                print("{}은(는) 치명타를 입었다".format(opp.name))
                print("{}은(는) {}의 피해를 입었다".format(opp.name, player_dmg * 2))
                if opp.hp - player_dmg * 2 <= 0:
                    opp.hp -= player_dmg * 2
                    print("{}은(는) 쓰러졌다!".format(opp.name))
                    input()
                    break
                else:
                    opp.hp -= player_dmg * 2
                
            else:
                print("{}은(는) {}의 피해를 입었다".format(opp.name, player_dmg))
                if opp.hp - player_dmg <= 0:
                    opp.hp -= player_dmg
                    print("{}은(는) 쓰러졌다".format(opp.name))
                    input()
                    break
                else:
                    opp.hp -= player_dmg
                
            print("{}은(는) 공격을 시도했다".format(opp.name))
            print("{}는 {}의 피해를 입었다".format(player.displayname, opp.dmg))
            if player.hp - opp.dmg <= 0:
                clear()
                print("{}는 쓰러졌다".format(player.displayname))
                input()
                kill()
            else:
                player.hp -= opp.dmg
            for slot in player.skills:
                skill = player.skills[slot]
                skill_cooltime = skill["cooltime"]
                if skill_cooltime >= 1:
                    skill["cooltime"] -= 1
                else:
                    skill["cooltime"] = 0 
        elif ans == "2":
            for slot in player.skills:
                print("[{}]{}".format(slot, player.skills[slot]["name"]))
            print("[q]나가기 [0~9]슬롯번호")
            ans = input(": ")
            if ans.isdigit():
                try:
                    slot = int(ans)
                    skill = player.skills[slot]
                    skill_name = skill["name"]
                    skill_cooltime = skill["cooltime"]
                    skill_max_cooltime = skill["maxcooltime"]
                    skill_run = skill["run"]
                    skill_cost = skill["cost"]
                    if skill_cooltime == 0 and player.mp - skill_cost >= 0:
                        print("{}는 {}를 사용하였다!".format(player.displayname, skill_name))
                        exec(skill_run)
                        skill["cooltime"] = skill_max_cooltime
                        player.mp -= skill_cost
                        if opp.hp <= 0:
                            print("{}은(는) 쓰러졌다".format(opp.name))
                            input()
                            break
                        elif player.hp <= 0:
                            clear()
                            print("{}는 쓰러졌다".format(player.displayname))
                            input()
                            kill()
                        else:
                            pass
                        print("{}은(는) 공격을 시도했다".format(opp.name))
                        print("{}는 {}의 피해를 입었다".format(player.displayname, opp.dmg))
                        if player.hp - opp.dmg <= 0:
                            clear()
                            print("{}는 쓰러졌다".format(player.displayname))
                            input()
                            kill()
                        else:
                            player.hp -= opp.dmg
                    else:
                        if skill_cooltime > 0:
                            print("스킬 쿨타임이 아직 남았습니다")
                        if player.mp - skill_cost < 0:
                            print("스킬을 시전할 마나가 부족합니다({}더 필요)".format(skill_cost - player.mp))
                    for slot in player.skills:
                        skill = player.skills[slot]
                        skill_cooltime = skill["cooltime"]
                        if skill_cooltime >= 1:
                            skill["cooltime"] -= 1
                        else:
                            skill["cooltime"] = 0  
                except:
                    print("제대로 된 값을 입력하세요")
            elif ans == "q":
                pass        
            else:
                print("제대로 된 값을 입력하세요")
                
            
        elif ans == "3":
            for slot in player.item_inventory:
                print("[{}]{}<{}개>".format(slot, player.item_inventory[slot]["name"], player.item_inventory[slot]["stack"]))
            print("[q]나가기 [0~9]슬롯번호")
            ans = input(": ")
            if ans.isdigit():
                try:
                    slot = int(ans)
                    item = player.item_inventory[slot]
                    item_name = item["name"]
                    if player.item_inventory[slot]["stack"] >= 1:
                        code = player.item_inventory[slot]["code"]
                        exec(code)
                        if opp.hp <= 0:
                            print("{}은(는) 쓰러졌다".format(opp.name))
                            input()
                            break
                        elif player.hp <= 0:
                            clear()
                            print("{}는 쓰러졌다".format(player.displayname))
                            input()
                            kill()
                        else:
                            pass
                        player.item_inventory[slot]["stack"] -= 1
                        print("{}는 {}를 사용하였다!".format(player.displayname, item_name))
                        if player.item_inventory[slot]["stack"] == 0:
                            player.item_inventory[slot] = {"name":None, "stack":0, "code":""}
                        print("{}은(는) 공격을 시도했다".format(opp.name))
                        print("{}는 {}의 피해를 입었다".format(player.displayname, opp.dmg))
                        if player.hp - opp.dmg <= 0:
                            clear()
                            print("{}는 쓰러졌다".format(player.displayname))
                            input()
                            kill()
                        else:
                            player.hp -= opp.dmg
                    else:
                        print("사용할 아이템이 없습니다")
                    
                    for slot in player.skills:
                            skill = player.skills[slot]
                            skill_cooltime = skill["cooltime"]
                            if skill_cooltime >= 1:
                                skill["cooltime"] -= 1
                            else:
                                skill["cooltime"] = 0   


                except:
                    print("제대로 된 값을 입력하세요")
            elif ans == "q":
                pass
            else:
                print("제대로 된 값을 입력하세요")

        elif ans == "4":
            print("{}는 공격하기를 포기하였다!".format(player.displayname))
            print("{}은(는) 공격을 시도했다".format(opp.name))
            print("{}는 {}의 피해를 입었다".format(player.displayname, opp.dmg))
            if player.hp - opp.dmg <= 0:
                clear()
                print("{}는 쓰러졌다".format(player.displayname))
                input()
                kill()
            else:
                player.hp -= opp.dmg
                for slot in player.skills:
                    skill = player.skills[slot]
                    skill_cooltime = skill["cooltime"]
                    if skill_cooltime >= 1:
                        skill["cooltime"] -= 1
                    else:
                        skill["cooltime"] = 0
        else:
            print("제대로 된 값을 입력하세요")
        
            
        input()
    player.weapon_inventory[0]["durability"] -= turn
    for slot in player.skills:
        player.skills[slot]["cooltime"] = player.skills[slot]["maxcooltime"]



def main():
    global player, weapon_list, entity_list, skill_list, item_list
    clear()
    #main banner
    try:
        with open('main/banner.txt', 'r', encoding='UTF-8') as main_banner:
            banner = main_banner.readlines()
            for line in banner:
                print(line.strip('\n'))
    except:
        print(colored("ERROR WHILE LOADING main/banner.txt", 'red'))
    print("[1]세이브 파일 불러오기")
    print("[2]새로 만들기")
    print("[3]게임 종료")
    ans = input(": ")
    if ans == "1":
        with open('log/log.txt', 'a') as log:
                log.write('=======loading game at [{}:{}]=======\n'.format(datetime.now().hour, datetime.now().minute))
        #load weapon
        try:
            weapon_list = nt.ntobject('weapons/weapons.txt').node
            with open('log/log.txt', 'a') as log:
                log.write('[{}:{}]weapons loading complete\n'.format(datetime.now().hour, datetime.now().minute))

        except:
            print(colored("ERROR WHILE LOADING WEAPONS", 'red'))
        #load skill
        try:
            skill_list = nt.ntobject('skills/skills.txt').node
            with open('log/log.txt', 'a') as log:
                log.write('[{}:{}]skills loading complete\n'.format(datetime.now().hour, datetime.now().minute))
        except:
            print(colored("ERROR WHILE LOADING SKILLS", 'red'))
        #load item
        try:
            item_list = nt.ntobject('items/items.txt').node
            with open('log/log.txt', 'a') as log:
                log.write('[{}:{}]items loading complete\n'.format(datetime.now().hour, datetime.now().minute))
        except:
            print(colored("ERROR WHILE LOADING ITEMS", 'red'))
        #load entities(monster)
        try:
            entity_list = nt.ntobject('entities/entities.txt').node
            with open('log/log.txt', 'a') as log:
                log.write('[{}:{}]entities loading complete\n'.format(datetime.now().hour, datetime.now().minute))
        except:
            print(colored("ERROR WHILE LOADING ENTITIES", 'red'))
        player = Player()
        #load_savefile
        try:
            player.maxhp = nt.ntobject('saves/player.txt').attr("player")["maxhp"]
            player.hp = nt.ntobject('saves/player.txt').attr("player")["hp"]
            player.maxmp = nt.ntobject('saves/player.txt').attr("player")["maxmp"]
            player.mp = nt.ntobject('saves/player.txt').attr("player")["mp"]
            player.gold = nt.ntobject('saves/player.txt').attr("player")["gold"]
            player.xp = nt.ntobject('saves/player.txt').attr("player")["xp"]
            player.displayname = nt.ntobject('saves/player.txt').attr("player")["displayname"]
        except:
            open('saves/player.txt', 'w')
            save("")
            savepoint = ""

        weaponsdict = nt.ntobject('saves/weapons.txt').node
        for slot in weaponsdict:
            if slot == '':
                pass
            else:
                islot = int(slot)
                weapon = weaponsdict[slot]
                if weaponsdict[slot]["name"] == "None":
                    weapon["name"] = None
                else:
                    pass
                player.weapon_inventory[islot] = weapon
        skilldict = nt.ntobject('saves/skills.txt').node
        for slot in skilldict:
            if slot == '':
                pass
            else:
                islot = int(slot)
                skill = skilldict[slot]
                if skilldict[slot]["name"] == "None":
                    skill["name"] = None
                else:
                    pass
            player.skills[islot] = skill
        itemdict = nt.ntobject('saves/items.txt').node
        for slot in itemdict:
            if slot == '':
                pass
            else:
                islot = int(slot)
                item = itemdict[slot]
                if itemdict[slot]["name"] == "None":
                    item["name"] = None
                else:
                    pass
            player.item_inventory[islot] = item
        with open('log/log.txt', 'a') as log:
                log.write('[{}:{}]savefile loading complete\n'.format(datetime.now().hour, datetime.now().minute))
        #setup ==> if no savefile
        savepoint = nt.ntobject('saves/savepoint.txt').attr("savepoint")["savepoint"]
        if savepoint == "":
            try:
                main_ = nt.ntobject('main/setup.txt')
                with open('log/log.txt', 'a') as log:
                    log.write('[{}:{}]setup complete\n'.format(datetime.now().hour, datetime.now().minute))
                exec(main_.attr('setup')["run"])
            except:
                print(colored("ERROR WHILE SETUP", 'red'))
        else:
            world(savepoint)
            with open('log/log.txt', 'a') as log:
                    log.write('[{}:{}]savepoint loaded complete\n'.format(datetime.now().hour, datetime.now().minute))
    elif ans == "2":
        with open('log/log.txt', 'a') as log:
                log.write('=======loading game at [{}:{}]=======\n'.format(datetime.now().hour, datetime.now().minute))
        #load weapon
        try:
            weapon_list = nt.ntobject('weapons/weapons.txt').node
            with open('log/log.txt', 'a') as log:
                log.write('[{}:{}]weapons loading complete\n'.format(datetime.now().hour, datetime.now().minute))

        except:
            print(colored("ERROR WHILE LOADING WEAPONS", 'red'))
        #load skill
        try:
            skill_list = nt.ntobject('skills/skills.txt').node
            with open('log/log.txt', 'a') as log:
                log.write('[{}:{}]skills loading complete\n'.format(datetime.now().hour, datetime.now().minute))
        except:
            print(colored("ERROR WHILE LOADING SKILLS", 'red'))
        try:
            item_list = nt.ntobject('items/items.txt').node
            with open('log/log.txt', 'a') as log:
                log.write('[{}:{}]items loading complete\n'.format(datetime.now().hour, datetime.now().minute))
        except:
            print(colored("ERROR WHILE LOADING ITEMS", 'red'))
        #load entities(monster)
        try:
            entity_list = nt.ntobject('entities/entities.txt').node
            with open('log/log.txt', 'a') as log:
                log.write('[{}:{}]entities loading complete\n'.format(datetime.now().hour, datetime.now().minute))
        except:
            print(colored("ERROR WHILE LOADING ENTITIES", 'red'))
        player = Player()
        #load_savefile
        try:
            open('saves/player.txt', 'w')
            save("")
            savepoint = ""
        except:
            save("")
            savepoint = ""
        with open('log/log.txt', 'a') as log:
                log.write('[{}:{}]savefile loading complete\n'.format(datetime.now().hour, datetime.now().minute))
        #setup ==> if no savefile
        if savepoint == "":
            try:
                main_ = nt.ntobject('main/setup.txt')
                with open('log/log.txt', 'a') as log:
                    log.write('[{}:{}]setup complete\n'.format(datetime.now().hour, datetime.now().minute))
                exec(main_.attr('setup')["run"])
            except:
                print(colored("ERROR WHILE SETUP", 'red'))
        else:
            world(savepoint)
    elif ans == "3":
        quit()
    else:
        print("제대로 된 값을 입력하세요")
        input()
        main()    
    
    

if __name__ == '__main__':
    main()
    